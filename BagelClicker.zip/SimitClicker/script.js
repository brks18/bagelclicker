document.addEventListener("DOMContentLoaded", () => {
    let score = Number(localStorage.getItem("score")) || 0;
    let pointsPerClick = 1;
    let autoClickerInterval = null;
    let clickCount = Number(localStorage.getItem("clickCount")) || 0;
    let highScore = Number(localStorage.getItem("highScore")) || 0;
    let upgradesOwned = Number(localStorage.getItem("upgradesOwned")) || 0;
    let level = 1;
    let levelThreshold = 50;
    let totalGameTime = Number(localStorage.getItem("totalGameTime")) || 0;

    const image = document.getElementById("click-image");
    const scoreDisplay = document.getElementById("score");
    const clickCountDisplay = document.getElementById("click-count");
    const highScoreDisplay = document.getElementById("high-score");
    const levelDisplay = document.getElementById("level");
    const progressBar = document.getElementById("progress-bar");
    const upgrade1Button = document.getElementById("upgrade-1");
    const upgrade2Button = document.getElementById("upgrade-2");
    const autoClickerButton = document.getElementById("auto-clicker");
    const achievementDisplay = document.getElementById("achievement");

    // Başarımlar
    const achievements = [
        { name: "İlk 10 Tıklama", condition: () => clickCount >= 10 },
        { name: "İlk 100 Skor", condition: () => score >= 100 },
        { name: "İlk Güncelleme", condition: () => upgradesOwned >= 1 },
    ];

    // Tıklama ile Puan
    if (image) {
        image.addEventListener("click", () => {
            score += pointsPerClick;
            clickCount++;
            checkLevelUp();
            checkHighScore();
            checkAchievements();
            playSound("sounds/click.wav");
            showFloatingText(`+${pointsPerClick}`, image);
            updateScore();
        });
    }

    // Güncelleme 1: +2 Puan/Tık
    if (upgrade1Button) {
        upgrade1Button.addEventListener("click", () => {
            if (score >= 20) {
                score -= 20;
                pointsPerClick += 2;
                upgradesOwned++;
                checkAchievements();
                playSound("sounds/upgrade.wav");
                showFloatingText("+2 Puan Güçlendirme!", upgrade1Button);
                updateScore();
            } else {
                playSound("sounds/error.wav");
                showFloatingText("Yetersiz Puan!", upgrade1Button);
            }
        });
    }

    // Güncelleme 2: +10 Puan/Tık
    if (upgrade2Button) {
        upgrade2Button.addEventListener("click", () => {
            if (score >= 100) {
                score -= 100;
                pointsPerClick += 10;
                upgradesOwned++;
                checkAchievements();
                playSound("sounds/upgrade.wav");
                showFloatingText("+10 Puan Güçlendirme!", upgrade2Button);
                updateScore();
            } else {
                playSound("sounds/error.wav");
                showFloatingText("Yetersiz Puan!", upgrade2Button);
            }
        });
    }

    // Otomatik Tıklayıcı
    if (autoClickerButton) {
        autoClickerButton.addEventListener("click", () => {
            if (score >= 500 && !autoClickerInterval) {
                score -= 500;
                autoClickerInterval = setInterval(() => {
                    score += pointsPerClick;
                    clickCount++;
                    checkLevelUp();
                    checkHighScore();
                    checkAchievements();
                    updateScore();
                }, 1000);
                playSound("sounds/autoClick.wav");
                showFloatingText("Otomatik Tıklayıcı Aktif!", autoClickerButton);
            } else if (score < 500) {
                playSound("sounds/error.wav");
                showFloatingText("Yetersiz Puan!", autoClickerButton);
            }
        });
    }

    // Skor Güncelle
    function updateScore() {
        if (scoreDisplay) scoreDisplay.textContent = score;
        if (clickCountDisplay) clickCountDisplay.textContent = clickCount;
        if (highScoreDisplay) highScoreDisplay.textContent = highScore;
        if (levelDisplay) levelDisplay.textContent = level;
        updateProgressBar();

        // Verileri LocalStorage'da sakla
        localStorage.setItem("score", score);
        localStorage.setItem("clickCount", clickCount);
        localStorage.setItem("highScore", highScore);
        localStorage.setItem("upgradesOwned", upgradesOwned);
    }

    // En Yüksek Skoru Kontrol Et
    function checkHighScore() {
        if (score > highScore) {
            highScore = score;
            showFloatingText("Yeni Rekor!", document.body);
        }
    }

    // Seviye Kontrolü ve Artışı
    function checkLevelUp() {
        if (score >= level * levelThreshold) {
            level++;
            showFloatingText(`Seviye ${level} Oldunuz!`, document.body);
            progressBar.style.width = "0%"; // Progress bar'ı sıfırlamak
        }
        updateProgressBar();
    }

    // Progress Bar'ı Güncelle
    function updateProgressBar() {
        const progress = (score % (level * levelThreshold)) * 100 / (level * levelThreshold);
        progressBar.style.width = `${progress}%`;
    }

    // Başarımları Kontrol Et
    function checkAchievements() {
        achievements.forEach((achievement) => {
            if (achievement.condition() && achievementDisplay) {
                achievementDisplay.textContent = achievement.name;
            }
        });
    }

    // Ses Oynatma
    function playSound(soundFile) {
        const audio = new Audio(soundFile);
        audio.play().catch((error) => {
            console.error("Ses dosyası yüklenemedi:", error);
        });
    }

    // Yüzen Metin Efekti
    function showFloatingText(message, targetElement) {
        const floatingText = document.createElement("div");
        floatingText.className = "floating-text";
        floatingText.textContent = message;

        const rect = targetElement.getBoundingClientRect();
        floatingText.style.position = "absolute";
        floatingText.style.left = `${rect.left + rect.width / 2}px`;
        floatingText.style.top = `${rect.top - 20}px`;
        floatingText.style.transform = "translate(-50%, -50%)";
        floatingText.style.color = "#f1c40f";
        floatingText.style.fontSize = "20px";
        floatingText.style.fontWeight = "bold";

        document.body.appendChild(floatingText);

        setTimeout(() => {
            floatingText.remove();
        }, 1500);
    }

    // Puan ve seviye kaydetme fonksiyonları
    function saveGameData() {
        localStorage.setItem("score", score);
        localStorage.setItem("level", level);
        localStorage.setItem("clickCount", clickCount);
        localStorage.setItem("highScore", highScore);
        localStorage.setItem("upgradesOwned", upgradesOwned);
    }
    window.addEventListener("beforeunload", saveGameData);

    // Oyun verilerini yükleme
    window.addEventListener("load", () => {
        if (localStorage.getItem("score")) {
            score = Number(localStorage.getItem("score"));
            scoreDisplay.textContent = score;
        }
        if (localStorage.getItem("level")) {
            level = Number(localStorage.getItem("level"));
            levelDisplay.textContent = level;
        }
        if (localStorage.getItem("clickCount")) {
            clickCount = Number(localStorage.getItem("clickCount"));
            clickCountDisplay.textContent = clickCount;
        }
        if (localStorage.getItem("highScore")) {
            highScore = Number(localStorage.getItem("highScore"));
            highScoreDisplay.textContent = highScore;
        }
        if (localStorage.getItem("upgradesOwned")) {
            upgradesOwned = Number(localStorage.getItem("upgradesOwned"));
        }
    });

    // Tıklama ve seviye yükseltme animasyonları
    image.addEventListener("mousedown", function () {
        this.style.transform = "scale(0.95)";
    });
    image.addEventListener("mouseup", function () {
        this.style.transform = "scale(1)";
    });

    updateScore();
});